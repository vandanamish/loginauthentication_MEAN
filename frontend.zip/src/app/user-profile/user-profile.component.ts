
  
import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userhome',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  username:String='';
  userdata: any;
  constructor(private userservice:UserService, private _router:Router) { 
    this.userservice.user()
    .subscribe(
      data=>this.addName(data),
      error=>this._router.navigate(['/login'])
    )
  }

  addName(data){
    console.log(data)
    this.userdata = data;
    localStorage.setItem('userID', JSON.stringify(this.userdata.userid))

  }
  ngOnInit() {
  }

  logout(){
    this.userservice.logout()
    .subscribe(
      data=>{console.log(data);this._router.navigate(['/login'])},
      error=>console.error(error)
    )
  }

}

