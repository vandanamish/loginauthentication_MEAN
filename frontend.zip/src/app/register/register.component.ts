import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm:FormGroup = new FormGroup({
    gender:new FormControl(null,Validators.required),
    mobileno:new FormControl(null,Validators.required),
    email:new FormControl(null,[Validators.email,Validators.required]),
    username:new FormControl(null,Validators.required),
    userid:new FormControl(null,Validators.required),
    password:new FormControl(null,Validators.required),
  
  })
  display: string;
  responsemessage: any;
  message: any;
  constructor(private _router:Router,private userservice:UserService) { }

  ngOnInit() {
  }




  moveToLogin(){
    this._router.navigate(['/login']);
  }

  register(){

    console.log(this.registerForm.value)
    if(!this.registerForm.valid ){
      console.log('Invalid Form'); return;
    }

    this.userservice.register(JSON.stringify(this.registerForm.value))
    .subscribe(
      data=> {console.log(data);
        this.responsemessage=data
        if(this.responsemessage.error){ console.log(this.responsemessage.error) }
        else {   this._router.navigate(['/login']); }
    },
      error=>{console.error(error)
      }
    )
  
  }


  
}
