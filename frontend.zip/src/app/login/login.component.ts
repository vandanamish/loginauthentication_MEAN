import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm : FormGroup=new FormGroup({
    userid:new FormControl(null,Validators.required),
    password:new FormControl(null, Validators.required)
  });
  errormessage: any;
  userid: any;
  constructor(private _router:Router,private userservice:UserService) { }

  ngOnInit() {

    this.userid=JSON.parse(localStorage.getItem('userID'))
    console.log(this.userid)

  }

  moveToRegister(){
    this._router.navigate(['/register']);
  }

  login(){
    if(!this.loginForm.valid){
      console.log('Invalid');return;
    }

  
    this.userservice.login(JSON.stringify(this.loginForm.value))
    .subscribe(
      data=>{console.log(data);this._router.navigate(['/profile']);} ,
      error=>{
        console.error(error.error)
        this.errormessage=error.error;
      }
         )
  }

}
