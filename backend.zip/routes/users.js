var express = require('express');
var router = express.Router();
var User = require('../models/user');
var passport = require('passport');
/* GET users listing. */
// router.get('/', function(req, res, next) {
//   res.send('respond with a resource');
// });

router.post('/register', function (req, res, next) {

  console.log(req.body)

  var user = new User({
    email: req.body.email,
    username: req.body.username,
    userid: req.body.userid,
    password: User.hashPassword(req.body.password),
    mobileno: req.body.mobileno,
    gender: req.body.gender

  });


  User.findOne({ userid: req.body.userid }, function (err, users) {
    if (err) {
      //handle error here
    }

    //if a user was found, that means the user's email matches the entered email
    if (users) {
      var err = new Error('A user with that email has already registered. Please use a different email..')
      err.status = 400;
      res.json({ error: "This User Id already exist please try another user Id" });

      return next(err);
    } else {

      user.save((err, userdata) => {
        if (err) {
          console.log(req.body)
          res.json({ error: "error while adding" + err });
        }
        else {
          res.json({ msg: "successfully registered" });
        }
      })
    }
  });








});


router.post('/login', function (req, res, next) {
  passport.authenticate('local', function (err, user, info) {
    // if (err) { return res.status(501).json(err); }


    if (!user) { return res.status(501).json(info); }
    req.logIn(user, function (err) {
      if (err) { return res.status(501).json(err); }
      return res.status(200).json({ message: 'Login Success' });
    });
  })(req, res, next);
});

router.get('/user', isValidUser, function (req, res, next) {
  return res.status(200).json(req.user);
});

router.get('/logout', isValidUser, function (req, res, next) {
  req.logout();
  return res.status(200).json({ message: 'Logout Success' });
})

function isValidUser(req, res, next) {
  if (req.isAuthenticated()) next();
  else return res.status(401).json({ message: 'Unauthorized Request' });
}

module.exports = router;
